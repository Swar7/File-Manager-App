package com.example.myfiles2023beta;

import java.io.File;

public interface OnFileSelectedListener {
    void onFileCliced(File file);
    void onFileLongClicked(File file, int position);
}
